// WebCode Pro - Main JavaScript Functionality
class WebCodePro {
    constructor() {
        this.editor = null;
        this.currentFile = 'index.html';
        this.files = {
            'index.html': {
                content: `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحه من</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>سلام دنیا!</h1>
        <p>این یک صفحه وب ساده است.</p>
        <button onclick="showMessage()">کلیک کنید</button>
    </div>
    <script src="script.js"></script>
</body>
</html>`,
                language: 'html'
            },
            'styles.css': {
                content: `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.container {
    background: white;
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
    text-align: center;
    max-width: 500px;
    width: 90%;
}

h1 {
    color: #333;
    margin-bottom: 20px;
    font-size: 2.5rem;
}

p {
    color: #666;
    margin-bottom: 30px;
    font-size: 1.1rem;
    line-height: 1.6;
}

button {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    padding: 15px 30px;
    border-radius: 10px;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s ease;
}

button:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
}`,
                language: 'css'
            },
            'script.js': {
                content: `function showMessage() {
    alert('سلام! شما دکمه را کلیک کردید!');
}

// Add some interactive features
document.addEventListener('DOMContentLoaded', function() {
    console.log('صفحه بارگذاری شد!');
    
    // Add click effect to button
    const button = document.querySelector('button');
    if (button) {
        button.addEventListener('click', function() {
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'translateY(-2px)';
            }, 150);
        });
    }
});`,
                language: 'javascript'
            }
        };
        
        this.templates = {
            basic: {
                'index.html': `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحه ساده</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>صفحه ساده</h1>
        <p>این یک صفحه وب ساده و تمیز است.</p>
    </div>
</body>
</html>`,
                'styles.css': `body {
    font-family: 'Inter', sans-serif;
    margin: 0;
    padding: 0;
    background: #f5f5f5;
}

.container {
    max-width: 800px;
    margin: 50px auto;
    padding: 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}`
            },
            landing: {
                'index.html': `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لندینگ پیج</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="hero">
        <div class="container">
            <h1>به سایت ما خوش آمدید</h1>
            <p>بهترین راه‌حل برای کسب و کار شما</p>
            <button class="cta-button">شروع کنید</button>
        </div>
    </header>
    
    <section class="features">
        <div class="container">
            <h2>ویژگی‌ها</h2>
            <div class="feature-grid">
                <div class="feature-card">
                    <h3>سریع و ایمن</h3>
                    <p>با بهترین تکنولوژی‌های روز</p>
                </div>
                <div class="feature-card">
                    <h3>قابل اعتماد</h3>
                    <p>۹۹.۹٪ آپتایم تضمین شده</p>
                </div>
                <div class="feature-card">
                    <h3>پشتیبانی ۲۴/۷</h3>
                    <p>همیشه در کنار شما هستیم</p>
                </div>
            </div>
        </div>
    </section>
</body>
</html>`,
                'styles.css': `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    line-height: 1.6;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.hero {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 100px 0;
    text-align: center;
}

.hero h1 {
    font-size: 3rem;
    margin-bottom: 20px;
}

.hero p {
    font-size: 1.2rem;
    margin-bottom: 30px;
}

.cta-button {
    background: white;
    color: #667eea;
    padding: 15px 30px;
    border: none;
    border-radius: 5px;
    font-size: 1.1rem;
    cursor: pointer;
    transition: transform 0.3s;
}

.cta-button:hover {
    transform: translateY(-2px);
}

.features {
    padding: 80px 0;
    background: #f8f9fa;
}

.features h2 {
    text-align: center;
    margin-bottom: 50px;
    font-size: 2.5rem;
}

.feature-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}

.feature-card {
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    text-align: center;
}`
            },
            blog: {
                'index.html': `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>وبلاگ من</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <h1>وبلاگ من</h1>
            <nav class="nav">
                <a href="#">خانه</a>
                <a href="#">دسته‌بندی‌ها</a>
                <a href="#">درباره من</a>
                <a href="#">تماس</a>
            </nav>
        </div>
    </header>
    
    <main class="main">
        <div class="container">
            <article class="post">
                <h2>عنوان مقاله اول</h2>
                <div class="meta">تاریخ: ۱۴۰۳/۰۸/۱۵</div>
                <p>این یک متن نمونه برای مقاله اول است. در اینجا می‌توانید محتوای مورد نظر خود را قرار دهید.</p>
                <a href="#" class="read-more">ادامه مطلب</a>
            </article>
            
            <article class="post">
                <h2>عنوان مقاله دوم</h2>
                <div class="meta">تاریخ: ۱۴۰۳/۰۸/۱۰</div>
                <p>این یک متن نمونه برای مقاله دوم است. محتوای جذاب و مفید بنویسید.</p>
                <a href="#" class="read-more">ادامه مطلب</a>
            </article>
        </div>
    </main>
</body>
</html>`,
                'styles.css': `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    line-height: 1.6;
    color: #333;
    background: #f8f9fa;
}

.container {
    max-width: 800px;
    margin: 0 auto;
    padding: 0 20px;
}

.header {
    background: white;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    padding: 20px 0;
}

.header h1 {
    color: #333;
    margin-bottom: 10px;
}

.nav {
    display: flex;
    gap: 20px;
}

.nav a {
    color: #666;
    text-decoration: none;
    transition: color 0.3s;
}

.nav a:hover {
    color: #333;
}

.main {
    padding: 40px 0;
}

.post {
    background: white;
    padding: 30px;
    margin-bottom: 30px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.post h2 {
    color: #333;
    margin-bottom: 10px;
}

.meta {
    color: #666;
    font-size: 0.9rem;
    margin-bottom: 15px;
}

.read-more {
    display: inline-block;
    color: #007bff;
    text-decoration: none;
    margin-top: 10px;
}`
            },
            portfolio: {
                'index.html': `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نمونه کارها</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>سلام، من یک توسعه‌دهنده هستم</h1>
                <p>طراح و توسعه‌دهنده وب با تجربه کاری ۵ سال</p>
                <div class="skills">
                    <span class="skill">HTML/CSS</span>
                    <span class="skill">JavaScript</span>
                    <span class="skill">React</span>
                    <span class="skill">Node.js</span>
                </div>
            </div>
        </div>
    </header>
    
    <section class="projects">
        <div class="container">
            <h2>پروژه‌های من</h2>
            <div class="project-grid">
                <div class="project-card">
                    <div class="project-image"></div>
                    <h3>پروژه اول</h3>
                    <p>توضیحات پروژه اول</p>
                </div>
                <div class="project-card">
                    <div class="project-image"></div>
                    <h3>پروژه دوم</h3>
                    <p>توضیحات پروژه دوم</p>
                </div>
                <div class="project-card">
                    <div class="project-image"></div>
                    <h3>پروژه سوم</h3>
                    <p>توضیحات پروژه سوم</p>
                </div>
            </div>
        </div>
    </section>
</body>
</html>`,
                'styles.css': `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    line-height: 1.6;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.hero {
    background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
    color: white;
    padding: 100px 0;
    text-align: center;
}

.hero-content h1 {
    font-size: 3rem;
    margin-bottom: 20px;
}

.hero-content p {
    font-size: 1.2rem;
    margin-bottom: 30px;
}

.skills {
    display: flex;
    justify-content: center;
    gap: 15px;
    flex-wrap: wrap;
}

.skill {
    background: rgba(255,255,255,0.2);
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 0.9rem;
}

.projects {
    padding: 80px 0;
    background: #f8f9fa;
}

.projects h2 {
    text-align: center;
    margin-bottom: 50px;
    font-size: 2.5rem;
}

.project-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 30px;
}

.project-card {
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    transition: transform 0.3s;
}

.project-card:hover {
    transform: translateY(-5px);
}

.project-image {
    height: 200px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.project-card h3 {
    padding: 20px 20px 10px;
}

.project-card p {
    padding: 0 20px 20px;
    color: #666;
}`
            }
        };
        
        this.init();
    }
    
    async init() {
        await this.initMonacoEditor();
        this.setupEventListeners();
        this.initAnimations();
        this.loadFile('index.html');
        this.updatePreview();
        this.initCodeRain();
    }
    
    async initMonacoEditor() {
        require.config({ paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.44.0/min/vs' } });
        
        await new Promise((resolve) => {
            require(['vs/editor/editor.main'], resolve);
        });
        
        this.editor = monaco.editor.create(document.getElementById('codeEditor'), {
            value: '',
            language: 'html',
            theme: 'vs-dark',
            fontSize: 14,
            fontFamily: 'JetBrains Mono, monospace',
            automaticLayout: true,
            minimap: { enabled: true },
            scrollBeyondLastLine: false,
            wordWrap: 'on',
            bracketPairColorization: { enabled: true },
            guides: {
                bracketPairs: true,
                indentation: true
            }
        });
        
        // Editor change event
        this.editor.onDidChangeModelContent(() => {
            this.updateFileContent();
            this.updatePreview();
        });
    }
    
    setupEventListeners() {
        // File tree clicks
        document.getElementById('fileTree').addEventListener('click', (e) => {
            if (e.target.classList.contains('file-item') || e.target.parentElement.classList.contains('file-item')) {
                const fileItem = e.target.classList.contains('file-item') ? e.target : e.target.parentElement;
                const filename = fileItem.dataset.file;
                this.loadFile(filename);
            }
        });
        
        // Property panel controls
        document.getElementById('bgColor').addEventListener('change', (e) => {
            this.updateCSSProperty('background-color', e.target.value);
        });
        
        document.getElementById('fontFamily').addEventListener('change', (e) => {
            this.updateCSSProperty('font-family', e.target.value);
        });
        
        document.getElementById('fontSize').addEventListener('input', (e) => {
            document.getElementById('fontSizeValue').textContent = e.target.value + 'px';
            this.updateCSSProperty('font-size', e.target.value + 'px');
        });
        
        document.getElementById('devicePreview').addEventListener('change', (e) => {
            this.updateDevicePreview(e.target.value);
        });
        
        // Language selector
        document.getElementById('languageSelect').addEventListener('change', (e) => {
            this.changeLanguage(e.target.value);
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                switch(e.key) {
                    case 's':
                        e.preventDefault();
                        this.saveProject();
                        break;
                    case 'Enter':
                        e.preventDefault();
                        this.runCode();
                        break;
                }
            }
        });
    }
    
    initAnimations() {
        // Initialize Splitting.js for text animations
        Splitting();
        
        // Animate hero title
        anime({
            targets: '.hero-title .char',
            translateY: [100, 0],
            opacity: [0, 1],
            easing: 'easeOutExpo',
            duration: 1400,
            delay: (el, i) => 30 * i
        });
        
        // Animate elements on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Observe elements for scroll animations
        document.querySelectorAll('.hover-lift').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });
    }
    
    initCodeRain() {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const codeRain = document.getElementById('codeRain');
        codeRain.appendChild(canvas);
        
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        const chars = '01{}[]()<>+-*/=;:.,?!@#$%^&*';
        const fontSize = 14;
        const columns = canvas.width / fontSize;
        const drops = Array(Math.floor(columns)).fill(1);
        
        function draw() {
            ctx.fillStyle = 'rgba(30, 30, 30, 0.05)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            ctx.fillStyle = '#00d4ff';
            ctx.font = fontSize + 'px JetBrains Mono';
            
            for (let i = 0; i < drops.length; i++) {
                const text = chars[Math.floor(Math.random() * chars.length)];
                ctx.fillText(text, i * fontSize, drops[i] * fontSize);
                
                if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                    drops[i] = 0;
                }
                drops[i]++;
            }
        }
        
        setInterval(draw, 50);
        
        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });
    }
    
    loadFile(filename) {
        if (!this.files[filename]) {
            this.files[filename] = {
                content: `// فایل جدید: ${filename}\n`,
                language: this.getLanguageFromFilename(filename)
            };
        }
        
        this.currentFile = filename;
        
        // Update active file in UI
        document.querySelectorAll('.file-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-file="${filename}"]`).classList.add('active');
        
        // Update editor content
        this.editor.setValue(this.files[filename].content);
        
        // Update language
        const language = this.files[filename].language;
        monaco.editor.setModelLanguage(this.editor.getModel(), language);
        document.getElementById('languageSelect').value = language;
        
        // Animate file switch
        anime({
            targets: '#codeEditor',
            opacity: [0.5, 1],
            duration: 300,
            easing: 'easeOutQuad'
        });
    }
    
    updateFileContent() {
        if (this.files[this.currentFile]) {
            this.files[this.currentFile].content = this.editor.getValue();
        }
    }
    
    updatePreview() {
        const preview = document.getElementById('previewFrame');
        const content = this.generatePreviewContent();
        
        const blob = new Blob([content], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        preview.src = url;
    }
    
    generatePreviewContent() {
        let htmlContent = '';
        let cssContent = '';
        let jsContent = '';
        
        // Combine all files
        Object.keys(this.files).forEach(filename => {
            if (filename.endsWith('.html')) {
                htmlContent = this.files[filename].content;
            } else if (filename.endsWith('.css')) {
                cssContent += this.files[filename].content + '\n';
            } else if (filename.endsWith('.js')) {
                jsContent += this.files[filename].content + '\n';
            }
        });
        
        // If no HTML file, create a basic structure
        if (!htmlContent) {
            htmlContent = `<!DOCTYPE html>
<html>
<head>
    <title>Preview</title>
</head>
<body>
    <h1>پیش‌نمایش</h1>
</body>
</html>`;
        }
        
        // Inject CSS and JS into HTML
        let previewContent = htmlContent;
        
        if (cssContent) {
            const styleTag = `<style>\n${cssContent}\n</style>`;
            previewContent = previewContent.replace('</head>', styleTag + '\n</head>');
        }
        
        if (jsContent) {
            const scriptTag = `<script>\n${jsContent}\n<\/script>`;
            previewContent = previewContent.replace('</body>', scriptTag + '\n</body>');
        }
        
        return previewContent;
    }
    
    updateCSSProperty(property, value) {
        // Find or create CSS file
        let cssFile = Object.keys(this.files).find(f => f.endsWith('.css'));
        if (!cssFile) {
            cssFile = 'styles.css';
            this.files[cssFile] = {
                content: '/* Generated CSS */\nbody {\n}\n',
                language: 'css'
            };
        }
        
        const cssContent = this.files[cssFile].content;
        
        // Update or add the property
        const bodyRegex = /body\s*{([^}]*)}/;
        if (bodyRegex.test(cssContent)) {
            let updatedContent = cssContent.replace(bodyRegex, (match, properties) => {
                const propRegex = new RegExp(`${property}:\s*[^;]+;?`, 'g');
                if (propRegex.test(properties)) {
                    return match.replace(propRegex, `${property}: ${value};`);
                } else {
                    return `body {\n    ${properties}\n    ${property}: ${value};\n}`;
                }
            });
            this.files[cssFile].content = updatedContent;
        } else {
            this.files[cssFile].content += `\nbody {\n    ${property}: ${value};\n}\n`;
        }
        
        // Update preview if currently viewing CSS file
        if (this.currentFile === cssFile) {
            this.editor.setValue(this.files[cssFile].content);
        }
        
        this.updatePreview();
    }
    
    updateDevicePreview(device) {
        const preview = document.getElementById('previewFrame');
        const devices = {
            desktop: { width: '100%', height: '100%' },
            tablet: { width: '768px', height: '1024px' },
            mobile: { width: '375px', height: '667px' }
        };
        
        const size = devices[device];
        if (size) {
            preview.style.width = size.width;
            preview.style.height = size.height;
            preview.style.margin = device !== 'desktop' ? '20px auto' : '0';
            preview.style.display = 'block';
        }
        
        // Animate the transition
        anime({
            targets: preview,
            scale: [0.8, 1],
            duration: 300,
            easing: 'easeOutQuad'
        });
    }
    
    changeLanguage(language) {
        monaco.editor.setModelLanguage(this.editor.getModel(), language);
        
        // Update file extension if needed
        const currentLang = this.getLanguageFromFilename(this.currentFile);
        if (currentLang !== language) {
            const newExtension = this.getExtensionFromLanguage(language);
            const newFilename = this.currentFile.replace(/\.[^.]+$/, newExtension);
            
            this.files[newFilename] = this.files[this.currentFile];
            delete this.files[this.currentFile];
            this.currentFile = newFilename;
            
            this.updateFileTree();
        }
    }
    
    getLanguageFromFilename(filename) {
        const extensions = {
            '.html': 'html',
            '.css': 'css',
            '.js': 'javascript',
            '.php': 'php',
            '.py': 'python',
            '.json': 'json',
            '.xml': 'xml'
        };
        
        const ext = filename.substring(filename.lastIndexOf('.'));
        return extensions[ext] || 'plaintext';
    }
    
    getExtensionFromLanguage(language) {
        const extensions = {
            'html': '.html',
            'css': '.css',
            'javascript': '.js',
            'php': '.php',
            'python': '.py',
            'json': '.json',
            'xml': '.xml'
        };
        
        return extensions[language] || '.txt';
    }
    
    updateFileTree() {
        const fileTree = document.getElementById('fileTree');
        fileTree.innerHTML = '<h3 class="text-sm font-semibold mb-4 text-gray-400">پروژه فعلی</h3>';
        
        Object.keys(this.files).forEach(filename => {
            const fileItem = document.createElement('div');
            fileItem.className = `file-item ${filename === this.currentFile ? 'active' : ''}`;
            fileItem.dataset.file = filename;
            
            const icon = this.getFileIcon(filename);
            fileItem.innerHTML = `<span>${icon}</span> ${filename}`;
            
            fileTree.appendChild(fileItem);
        });
    }
    
    getFileIcon(filename) {
        if (filename.endsWith('.html')) return '🌐';
        if (filename.endsWith('.css')) return '🎨';
        if (filename.endsWith('.js')) return '⚡';
        if (filename.endsWith('.php')) return '🔧';
        if (filename.endsWith('.py')) return '🐍';
        return '📄';
    }
    
    // Public methods for UI interactions
    createNewFile() {
        const filename = prompt('نام فایل جدید را وارد کنید:');
        if (filename && !this.files[filename]) {
            this.files[filename] = {
                content: `// فایل جدید: ${filename}\n`,
                language: this.getLanguageFromFilename(filename)
            };
            this.updateFileTree();
            this.loadFile(filename);
            this.showNotification('فایل جدید ایجاد شد');
        }
    }
    
    openFile() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.html,.css,.js,.php,.py';
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    this.files[file.name] = {
                        content: e.target.result,
                        language: this.getLanguageFromFilename(file.name)
                    };
                    this.updateFileTree();
                    this.loadFile(file.name);
                    this.showNotification('فایل بارگذاری شد');
                };
                reader.readAsText(file);
            }
        };
        input.click();
    }
    
    runCode() {
        this.updatePreview();
        this.showNotification('کد اجرا شد');
        
        // Animate run button
        anime({
            targets: 'button[onclick="runCode()"]',
            scale: [1, 0.95, 1],
            duration: 200,
            easing: 'easeOutQuad'
        });
    }
    
    saveProject() {
        // Simulate save (in real app, would send to server)
        localStorage.setItem('webcodepro-project', JSON.stringify(this.files));
        this.showNotification('پروژه ذخیره شد');
        
        // Animate save button
        anime({
            targets: 'button[onclick="saveProject()"]',
            scale: [1, 0.95, 1],
            duration: 200,
            easing: 'easeOutQuad'
        });
    }
    
    shareProject() {
        const shareUrl = `${window.location.origin}${window.location.pathname}?shared=true`;
        
        if (navigator.share) {
            navigator.share({
                title: 'WebCode Pro - پروژه اشتراکی',
                url: shareUrl
            });
        } else {
            navigator.clipboard.writeText(shareUrl).then(() => {
                this.showNotification('لینک اشتراک کپی شد');
            });
        }
    }
    
    loadTemplate(templateName) {
        if (this.templates[templateName]) {
            this.files = { ...this.templates[templateName] };
            this.updateFileTree();
            this.loadFile('index.html');
            this.updatePreview();
            this.showNotification(`قالب ${templateName} بارگذاری شد`);
        }
    }
    
    showExportModal() {
        document.getElementById('exportModal').style.display = 'flex';
        anime({
            targets: '.modal-content',
            scale: [0.8, 1],
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutQuad'
        });
    }
    
    closeExportModal() {
        anime({
            targets: '.modal-content',
            scale: [1, 0.8],
            opacity: [1, 0],
            duration: 200,
            easing: 'easeInQuad',
            complete: () => {
                document.getElementById('exportModal').style.display = 'none';
            }
        });
    }
    
    exportProject(format) {
        let content = '';
        let filename = `project.${format}`;
        
        switch(format) {
            case 'html':
                content = this.generatePreviewContent();
                filename = 'index.html';
                break;
            case 'css':
                content = this.files['styles.css']?.content || '/* Empty CSS */';
                filename = 'styles.css';
                break;
            case 'js':
                content = this.files['script.js']?.content || '// Empty JS';
                filename = 'script.js';
                break;
            case 'php':
                content = this.files['index.php']?.content || '<?php\n// Empty PHP\n?>';
                filename = 'index.php';
                break;
            case 'python':
                content = this.files['main.py']?.content || '# Empty Python\nprint("Hello World")';
                filename = 'main.py';
                break;
            case 'zip':
                this.exportAsZip();
                return;
        }
        
        this.downloadFile(content, filename);
        this.closeExportModal();
        this.showNotification(`فایل ${filename} دانلود شد`);
    }
    
    exportAsZip() {
        // Simulate ZIP export (in real app, would use JSZip library)
        this.showNotification('در حال آماده‌سازی فایل ZIP...');
        
        setTimeout(() => {
            const zipContent = JSON.stringify(this.files, null, 2);
            this.downloadFile(zipContent, 'project-files.json');
            this.showNotification('فایل ZIP دانلود شد');
        }, 1000);
    }
    
    downloadFile(content, filename) {
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
    
    confirmExport() {
        // This would be called from the export modal
        this.showNotification('خروجی با موفقیت ایجاد شد');
        this.closeExportModal();
    }
    
    showNotification(message) {
        const notification = document.getElementById('notification');
        const notificationText = document.getElementById('notificationText');
        
        notificationText.textContent = message;
        notification.classList.add('show');
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
}

// Global functions for UI interactions
function createNewFile() {
    window.webCodePro.createNewFile();
}

function openFile() {
    window.webCodePro.openFile();
}

function runCode() {
    window.webCodePro.runCode();
}

function saveProject() {
    window.webCodePro.saveProject();
}

function shareProject() {
    window.webCodePro.shareProject();
}

function showExportModal() {
    window.webCodePro.showExportModal();
}

function closeExportModal() {
    window.webCodePro.closeExportModal();
}

function exportProject(format) {
    window.webCodePro.exportProject(format);
}

function confirmExport() {
    window.webCodePro.confirmExport();
}

function loadTemplate(templateName) {
    window.webCodePro.loadTemplate(templateName);
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.webCodePro = new WebCodePro();
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', () => {
            const navLinks = document.querySelector('.nav-links');
            navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
        });
    }
});